const $=s=>document.querySelector(s);
let token=localStorage.token;
async function api(url,opt={}){opt.headers={...(opt.headers||{}),...(token?{Authorization:"Bearer "+token}:{})}; if(opt.body)opt.headers["Content-Type"]="application/json"; const r=await fetch(url,opt);const j=await r.json();if(!r.ok)throw Error(j.error||"error");return j}
async function render(){
 if(!token){$("#app").innerHTML=`<h2>Login</h2><input id=u placeholder=username><input id=p type=password placeholder=password><button onclick="login()">Login</button><h2>Register</h2><button onclick="register()">Buat akun</button>`;return}
 const [me,tasks]=await Promise.all([api("/api/me"),api("/api/tasks")]);
 $("#app").innerHTML=`<p>saldo: <b>Rp${me.user.balance.toLocaleString("id-ID")}</b></p>
 <button onclick="payout()">atur rekening/e-wallet</button> <button onclick="withdraw()">tarik saldo</button>
 <h2>tugas</h2>${tasks.map(t=>`<article><h3>${t.title}</h3><p>${t.description}</p><b>Rp${t.reward.toLocaleString("id-ID")}</b><br><a href="${t.download_url}" target="_blank">download</a><br><input id="code-${t.id}" placeholder="kode undangan"><button onclick="submitTask(${t.id})">submit</button></article>`).join("")}<button onclick="logout()">logout</button>`;
}
async function login(){try{let j=await api("/api/auth/login",{method:"POST",body:JSON.stringify({username:$("#u").value,password:$("#p").value})});token=j.token;localStorage.token=token;render()}catch(e){alert(e.message)}}
async function register(){let u=prompt("username"),p=prompt("password");try{let j=await api("/api/auth/register",{method:"POST",body:JSON.stringify({username:u,password:p})});token=j.token;localStorage.token=token;render()}catch(e){alert(e.message)}}
async function submitTask(id){try{await api(`/api/tasks/${id}/submit`,{method:"POST",body:JSON.stringify({invite_code:$(`#code-${id}`).value})});alert("dikirim untuk verifikasi admin")}catch(e){alert(e.message)}}
async function payout(){let method=prompt("bank atau ewallet"),account=prompt("nomor rekening/e-wallet"),name=prompt("nama pemilik");try{await api("/api/me/payout-method",{method:"POST",body:JSON.stringify({method,account,name})});alert("tersimpan")}catch(e){alert(e.message)}}
async function withdraw(){let amount=Number(prompt("jumlah penarikan (Rp)"));try{await api("/api/withdraw",{method:"POST",body:JSON.stringify({amount})});alert("permintaan penarikan dibuat");render()}catch(e){alert(e.message)}}
function logout(){localStorage.removeItem("token");token=null;render()} render();